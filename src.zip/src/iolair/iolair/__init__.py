"""iolair package initializer."""
